﻿using Esame_c_.DAL;
using Esame_c_.Models;

namespace Esame_c_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool continua = true;
            while (continua)
            {
                Console.WriteLine("Digita: \n" + 
                    "C per inserire un nuovo volo \n" +
                    "R per visualizzare tutti i voli\n" + 
                    "U per modificare un volo\n" +
                    "D per rimuovere un volo\n" +
                    "I per visualizzare un volo specifico\n" +
                    "N per conoscere il terminal, gate e stato di un volo\n" +  
                    "M per cambiare lo stato di un volo\n" +
                    "T per il numero di voli presenti in un terminal\n" +
                    "V per esportare come CSV\n" +
                    "E per l'elenco delle destinazioni in ordine crescente per numero di voli\n" +
                    "Q per uscire  ");
                string? inputUtente = Console.ReadLine().ToUpper();

                switch (inputUtente)
                {
                    case "C":
                        Console.WriteLine("Inserisci il nome e la sigla dell'aeroporto di partenza");
                        string? aeroPart = Console.ReadLine();
                        Console.WriteLine("Inserisci il nome e la sigla dell'aeroporto di arrivo");
                        string? aeroArr = Console.ReadLine();

                        DateTime dataVolo = DateTime.MinValue; ;
                        bool dataValida = false;

                        while (!dataValida)
                        {
                            Console.WriteLine("Inserisci la data (formato yyyy-MM-dd HH:mm):");
                            string? data = Console.ReadLine();

                            if (DateTime.TryParseExact(data, "yyyy-MM-dd HH:mm", null, System.Globalization.DateTimeStyles.None, out dataVolo))
                            {
                                dataValida = true; 
                            }
                            else
                            {
                                Console.WriteLine("Formato data non valido. Riprova.");
                            }
                        }

                        Console.WriteLine("Inserisci il codice del volo");
                        string? codice = Console.ReadLine();
                        Console.WriteLine("Inserisci il terminal");
                        string? terminal = Console.ReadLine();
                        Console.WriteLine("Inserisci il gate");
                        string? gate = Console.ReadLine();

                        string? stato = "";
                        bool statoValido = false;

                        while (!statoValido)
                        {
                            Console.WriteLine("Inserisci lo stato del volo ('in arrivo', 'imbarco in corso', 'in partenza', 'in ritardo', 'cancellato'):");
                            stato = Console.ReadLine();

                            if (stato == "in arrivo" || stato == "imbarco in corso" || stato == "in partenza" || stato == "in ritardo" || stato == "cancellato")
                            {
                                statoValido = true;
                            }
                            else
                            {
                                Console.WriteLine("Stato non valido. Riprova.");
                            }
                        }


                        Volo volo = new Volo()
                        {
                            AeroPart = aeroPart,
                            AeroArr = aeroArr,
                            Tempo = dataVolo,
                            Codice = codice,
                            Terminal = terminal,
                            Gate = gate,
                            Stato = stato
                        };

                        if (VoloDAL.getIstanza().insert(volo))
                            Console.WriteLine("Elemento inserito");
                        else
                            Console.WriteLine("Elemento non inserito");

                        break;
                    case "R":
                        List<Volo> voli = VoloDAL.getIstanza().findAll();

                        if (voli.Count > 0)
                        {
                            foreach (var voloind in voli)
                            {
                                Console.WriteLine($"Aeroporto di partenza: {voloind.AeroPart}, Aeroporto d'arrivo: {voloind.AeroArr}, " +
                                    $"Data e Ora: {voloind.Tempo}, Codice: {voloind.Codice}, Terminal: {voloind.Terminal}, " +
                                    $"Gate: {voloind.Gate}, Stato: {voloind.Stato}");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Nessun volo trovato.");
                        }
                        break;
                    case "I":
                        Console.WriteLine("Inserisci il codice del volo da trovare:");
                        string? codiceVolo = Console.ReadLine();

                        Volo volo1 = VoloDAL.getIstanza().find(codiceVolo);

                        if (volo1 != null)
                        {
                            Console.WriteLine($"Aeroporto di partenza: {volo1.AeroPart}, Aeroporto d'arrivo: {volo1.AeroArr}, " +
                                    $"Data e Ora: {volo1.Tempo}, Codice: {volo1.Codice}, Terminal: {volo1.Terminal}, " +
                                    $"Gate: {volo1.Gate}, Stato: {volo1.Stato}");
                        }
                        else
                        {
                            Console.WriteLine("Nessun volo trovato con quel codice.");
                        }

                        break;
                    case "U":
                        Console.WriteLine("Inserisci il codice del volo da aggiornare:");
                        string? codiceUpdate = Console.ReadLine();

                        if (VoloDAL.getIstanza().updateByCodice(codiceUpdate))
                            Console.WriteLine("Volo aggiornato con successo!");
                        else
                            Console.WriteLine("Errore durante l'aggiornamento del volo.");
                        break;
                    case "D":
                        Console.WriteLine("Inserisci il codice del volo da eliminare:");
                        string? codiceDelete = Console.ReadLine();

                        if (VoloDAL.getIstanza().deleteByCodice(codiceDelete))
                            Console.WriteLine("Volo eliminato con successo!");
                        else
                            Console.WriteLine("Errore durante l'eliminazione del volo.");
                        break;
                    case "N":
                        Console.WriteLine("Inserisci il codice del volo");
                        string? codiceVolo1 = Console.ReadLine()?.Trim();
                        if (!string.IsNullOrEmpty(codiceVolo1))
                        {
                            Volo? volocod = VoloDAL.getIstanza().findByCodice(codiceVolo1);

                            if (volocod != null)
                            {
                                Console.WriteLine($"Terminal: {volocod.Terminal}, Gate: {volocod.Gate}, Stato: {volocod.Stato}");
                            }
                            else
                            {
                                Console.WriteLine("Volo non trovato.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Codice volo non valido.");
                        }

                        break;
                    case "M":
                        Console.WriteLine("Inserisci il codice del volo");
                        string? codiceVolo2 = Console.ReadLine()?.Trim();
                        if (!string.IsNullOrEmpty(codiceVolo2))
                        {
                            Console.WriteLine("Inserisci il nuovo stato ('in arrivo', 'imbarco in corso', 'in partenza', 'in ritardo', 'cancellato'):");
                            string? nuovoStato = Console.ReadLine()?.Trim().ToLower();

                            if (!string.IsNullOrEmpty(nuovoStato))
                            {
                                bool aggiornato = VoloDAL.getIstanza().updateStatoByCodice(codiceVolo2, nuovoStato);

                                if (aggiornato)
                                {
                                    Console.WriteLine("Stato del volo aggiornato correttamente.");
                                }
                                else
                                {
                                    Console.WriteLine("Errore durante l'aggiornamento dello stato del volo.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Stato non valido.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Codice volo non valido.");
                        }

                        break;
                    case "T":
                        Console.WriteLine("Inserisci il terminal:");
                        string? terminalins = Console.ReadLine()?.Trim().ToUpper();

                        
                        int numVoli = VoloDAL.getIstanza().numeroVoliInTerminalPerStato(terminalins);

                        if (numVoli > 0)
                        {
                            Console.WriteLine($"Numero di voli nel terminal {terminalins} con stato 'imbarco in corso' o 'in partenza': {numVoli}");
                        }
                        else
                        {
                            Console.WriteLine($"Nessun volo trovato nel terminal {terminalins} con stato 'imbarco in corso' o 'in partenza'.");
                        }
                        break;
                    case "V":
                        Console.WriteLine("Inserisci lo stato dei voli da esportare ('in arrivo', 'imbarco in corso', 'in partenza', 'in ritardo', 'cancellato'):");
                        string? statov = Console.ReadLine()?.Trim().ToLower();

                        if (!string.IsNullOrEmpty(statov))
                        {
                            Console.WriteLine("Inserisci il percorso completo del file CSV");
                            string? percorsoFile = Console.ReadLine()?.Trim();

                            if (!string.IsNullOrEmpty(percorsoFile))
                            {
                                bool esportato = VoloDAL.getIstanza().esportaVoliInStatoCSV(statov, percorsoFile);
                                if (esportato)
                                {
                                    Console.WriteLine("Esportazione completata con successo.");
                                }
                                else
                                {
                                    Console.WriteLine("Esportazione fallita.");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Percorso file non valido.");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Stato non valido.");
                        }
                        break;
                    case "E":
                        List<(string destinazione, int numeroVoli)> destinazioni = VoloDAL.getIstanza().elencoDestinazioniPerNumeroVoli();

                        if (destinazioni.Count > 0)
                        {
                            Console.WriteLine("Elenco delle destinazioni per numero di voli (in ordine crescente):");
                            foreach (var (destinazione, numeroVoli) in destinazioni)
                            {
                                Console.WriteLine($"Destinazione: {destinazione}, Numero di voli: {numeroVoli}");
                            }
                        }
                        else
                        {
                            Console.WriteLine("Nessuna destinazione trovata.");
                        }
                        break;

                    case "Q":
                        continua = false;
                        break;

                    default:
                        Console.WriteLine("Opzione non valida. Riprova.");
                        break;
                }
            }
        }
    }
}
