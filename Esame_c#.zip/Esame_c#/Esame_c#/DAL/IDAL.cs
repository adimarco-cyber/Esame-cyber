﻿using Esame_c_.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esame_c_.DAL
{
    internal interface IDAL<T>
    {
        public List<T> findAll();
        public T find(string t);
        public bool insert(T t);
        public bool updateByCodice(string t);
        public bool deleteByCodice(string t);
        public T? findByCodice(string t);
        public bool updateStatoByCodice(string t, string y);
        public bool esportaVoliInStatoCSV(string t, string y);
        public List<(string destinazione, int numeroVoli)> elencoDestinazioniPerNumeroVoli();
        public int numeroVoliInTerminalPerStato(string t);

    }
}
