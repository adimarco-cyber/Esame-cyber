﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esame_c_.DAL
{
    internal class Config
    {
        public static readonly string credenziali = "" +
              "Server=DESKTOP-2RO81JS\\SQLEXPRESS;" +
              "Database=esame_aeroporto;" +
              "User Id=academy;" +
              "Password=academy!;" +
              "MultipleActiveResultSets=true;" +
              "Encrypt=false;" +
              "TrustServerCertificate=false";
    }
}
