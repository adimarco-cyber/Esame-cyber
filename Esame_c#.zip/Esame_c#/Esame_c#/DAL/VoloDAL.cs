﻿using Esame_c_.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esame_c_.DAL
{
    internal class VoloDAL : IDAL <Volo>
    {
        private static VoloDAL? istanza;

        public static VoloDAL getIstanza()
        {
            if (istanza is null)
                istanza = new VoloDAL();

            return istanza;
        }

        private VoloDAL() { }

        public bool deleteByCodice(string codice)
        {
            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    
                    string query = "DELETE FROM Volo WHERE Codice = @Codice";

                    SqlCommand command = new();
                    command.Connection = conness;
                    command.CommandText = query;

                    
                    command.Parameters.AddWithValue("@Codice", codice);

                    conness.Open();

                    
                    int affRows = command.ExecuteNonQuery();

                    conness.Close();

                    
                    if (affRows > 0)
                        return true;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return false; 
        }

        public List<Volo> findAll()
        {
            List<Volo> voli = new List<Volo>();

            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    string query = "SELECT * FROM Volo;";
                    SqlCommand command = new(query, conness);
                    conness.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Volo volo = new Volo
                        {
                            AeroPart = reader["AeroPart"].ToString(),
                            AeroArr = reader["AeroArr"].ToString(),
                            Tempo = DateTime.Parse(reader["Tempo"].ToString()!),
                            Codice = reader["Codice"].ToString(),
                            Terminal = reader["Terminal"].ToString(),
                            Gate = reader["Gate"].ToString(),
                            Stato = reader["Stato"].ToString()
                        };

                        voli.Add(volo);
                    }

                    conness.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return voli;
        }

        public Volo find(string codice)
        {
            Volo? volo1 = null;

            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    string query = "SELECT * FROM Volo WHERE Codice = @Codice;";

                    SqlCommand command = new SqlCommand(query, conness);
                    command.Parameters.AddWithValue("@Codice", codice);

                    conness.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            volo1 = new Volo
                            {
                                AeroPart = reader["AeroPart"].ToString(),
                                AeroArr = reader["AeroArr"].ToString(),
                                Tempo = (DateTime)reader["Tempo"],
                                Codice = reader["Codice"].ToString(),
                                Terminal = reader["Terminal"].ToString(),
                                Gate = reader["Gate"].ToString(),
                                Stato = reader["Stato"].ToString()
                            };
                        }
                    }

                    conness.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante la ricerca del volo: {ex.Message}");
            }

            return volo1;
        }

        public bool insert(Volo t)
        {
            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    string query = "INSERT INTO Volo(AeroPart, AeroArr, Tempo, Codice, Terminal, Gate, Stato) " +
                        "           VALUES (@AeroPart, @AeroArr, @Tempo, @Codice, @Terminal, @Gate, @Stato);";

                    SqlCommand command = new();
                    command.Connection = conness;
                    command.CommandText = query;
                    command.Parameters.AddWithValue("@AeroPart", t.AeroPart);
                    command.Parameters.AddWithValue("@AeroArr", t.AeroArr);
                    command.Parameters.AddWithValue("@Tempo", t.Tempo);
                    command.Parameters.AddWithValue("@Codice", t.Codice);
                    command.Parameters.AddWithValue("@Terminal", t.Terminal);
                    command.Parameters.AddWithValue("@Gate", t.Gate);
                    command.Parameters.AddWithValue("@Stato", t.Stato);

                    conness.Open();

                    int affRows = command.ExecuteNonQuery();

                    conness.Close();

                    if (affRows > 0)
                        return true;
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return false;
        }


        public bool updateByCodice(string codice)
        {
            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    Volo voloDaAggiornare = find(codice);

                    if (voloDaAggiornare == null)
                    {
                        Console.WriteLine("Nessun volo trovato con questo codice.");
                        return false;
                    }

                    Console.WriteLine($"Dettagli attuali del volo con codice {codice}:");
                    Console.WriteLine($"Partenza: {voloDaAggiornare.AeroPart}, Arrivo: {voloDaAggiornare.AeroArr}, Data: {voloDaAggiornare.Tempo}, \nTerminal: {voloDaAggiornare.Terminal}, Gate: {voloDaAggiornare.Gate}, Stato: {voloDaAggiornare.Stato}");

                    Console.WriteLine("Inserisci la nuova partenza (lascia vuoto per mantenere il valore attuale):");
                    string? nuovaPartenza = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(nuovaPartenza)) voloDaAggiornare.AeroPart = nuovaPartenza;

                    Console.WriteLine("Inserisci il nuovo arrivo (lascia vuoto per mantenere il valore attuale):");
                    string? nuovoArrivo = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(nuovoArrivo)) voloDaAggiornare.AeroArr = nuovoArrivo;

                    Console.WriteLine("Inserisci la nuova data e ora (lascia vuoto per mantenere il valore attuale):");
                    string? nuovaDataStr = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(nuovaDataStr) && DateTime.TryParse(nuovaDataStr, out DateTime nuovaData))
                        voloDaAggiornare.Tempo = nuovaData;

                    Console.WriteLine("Inserisci il nuovo terminal (lascia vuoto per mantenere il valore attuale):");
                    string? nuovoTerminal = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(nuovoTerminal)) voloDaAggiornare.Terminal = nuovoTerminal;

                    Console.WriteLine("Inserisci il nuovo gate (lascia vuoto per mantenere il valore attuale):");
                    string? nuovoGate = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(nuovoGate)) voloDaAggiornare.Gate = nuovoGate;

                    Console.WriteLine("Inserisci il nuovo stato (lascia vuoto per mantenere il valore attuale):");
                    string? nuovoStato = Console.ReadLine();
                    if (!string.IsNullOrWhiteSpace(nuovoStato)) voloDaAggiornare.Stato = nuovoStato;

                    string query = "UPDATE Volo SET AeroPart = @AeroPart, AeroArr = @AeroArr, Tempo = @Tempo, Terminal = @Terminal, " +
                                   "Gate = @Gate, Stato = @Stato WHERE Codice = @Codice";

                    SqlCommand command = new SqlCommand(query, conness);
                    command.Parameters.AddWithValue("@AeroPart", voloDaAggiornare.AeroPart);
                    command.Parameters.AddWithValue("@AeroArr", voloDaAggiornare.AeroArr);
                    command.Parameters.AddWithValue("@Tempo", voloDaAggiornare.Tempo);
                    command.Parameters.AddWithValue("@Terminal", voloDaAggiornare.Terminal);
                    command.Parameters.AddWithValue("@Gate", voloDaAggiornare.Gate);
                    command.Parameters.AddWithValue("@Stato", voloDaAggiornare.Stato);
                    command.Parameters.AddWithValue("@Codice", codice);

                    conness.Open();

                    int rowsAffected = command.ExecuteNonQuery();

                    conness.Close();

                    return rowsAffected > 0;
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante l'aggiornamento del volo: {ex.Message}");
                return false;
            }
        }

        public Volo? findByCodice(string codice)
        {
            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    string query = "SELECT Terminal, Gate, Stato FROM Volo WHERE Codice = @Codice;";

                    SqlCommand command = new SqlCommand(query, conness);
                    command.Parameters.AddWithValue("@Codice", codice);

                    conness.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        Volo volo = new Volo
                        {
                            Terminal = reader["Terminal"].ToString(),
                            Gate = reader["Gate"].ToString(),
                            Stato = reader["Stato"].ToString()
                        };

                        conness.Close();
                        return volo;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore: {ex.Message}");
            }



            return null;
        }
        public bool updateStatoByCodice(string codice, string nuovoStato)
        {
            if (nuovoStato != "in arrivo" && nuovoStato != "imbarco in corso" && nuovoStato != "in partenza" && nuovoStato != "in ritardo" && nuovoStato != "cancellato")
            {
                Console.WriteLine("Stato non valido. Gli stati validi sono: 'in arrivo', 'imbarco in corso', 'in partenza', 'in ritardo', 'cancellato'.");
                return false;
            }

            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    string query = "UPDATE Volo SET Stato = @NuovoStato WHERE Codice = @Codice;";

                    SqlCommand command = new SqlCommand(query, conness);
                    command.Parameters.AddWithValue("@NuovoStato", nuovoStato);
                    command.Parameters.AddWithValue("@Codice", codice);

                    conness.Open();
                    int rowsAffected = command.ExecuteNonQuery();

                    conness.Close();

                    if (rowsAffected > 0)
                    {
                        Console.WriteLine("Stato aggiornato con successo.");
                        return true;
                    }
                    else
                    {
                        Console.WriteLine("Codice volo non trovato.");
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore: {ex.Message}");
            }

            return false;
        }
        public bool esportaVoliInStatoCSV(string stato, string percorsoFile)
        {
            List<Volo> listaVoli = new List<Volo>();

            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    string query = "SELECT AeroPart, AeroArr, Tempo, Codice, Terminal, Gate, Stato FROM Volo WHERE Stato = @Stato";

                    SqlCommand command = new SqlCommand(query, conness);
                    command.Parameters.AddWithValue("@Stato", stato);

                    conness.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        Volo volo = new Volo
                        {
                            AeroPart = reader["AeroPart"].ToString(),
                            AeroArr = reader["AeroArr"].ToString(),
                            Tempo = Convert.ToDateTime(reader["Tempo"]),
                            Codice = reader["Codice"].ToString(),
                            Terminal = reader["Terminal"].ToString(),
                            Gate = reader["Gate"].ToString(),
                            Stato = reader["Stato"].ToString()
                        };

                        listaVoli.Add(volo);
                    }

                    conness.Close();
                }

                if (listaVoli.Count == 0)
                {
                    Console.WriteLine("Nessun volo trovato nello stato specificato.");
                    return false;
                }

                using (StreamWriter writer = new StreamWriter(percorsoFile, false, Encoding.UTF8))
                {
                    writer.WriteLine("AeroPart,AeroArr,Tempo,Codice,Terminal,Gate,Stato");

                    foreach (var volo in listaVoli)
                    {
                        writer.WriteLine($"{volo.AeroPart},{volo.AeroArr},{volo.Tempo},{volo.Codice},{volo.Terminal},{volo.Gate},{volo.Stato}");
                    }

                    writer.Flush();
                }

                Console.WriteLine($"Dati esportati con successo nel file: {percorsoFile}");
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante l'esportazione: {ex.Message}");
                return false;
            }

        }
        public List<(string destinazione, int numeroVoli)> elencoDestinazioniPerNumeroVoli()
        {
            List<(string destinazione, int numeroVoli)> destinazioni = new List<(string destinazione, int numeroVoli)>();

            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    string query = @"
                        SELECT AeroArr, COUNT(*) AS NumeroVoli
                        FROM Volo
                        GROUP BY AeroArr
                        ORDER BY NumeroVoli DESC;";

                    SqlCommand command = new SqlCommand(query, conness);

                    conness.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    while (reader.Read())
                    {
                        string? destinazione = reader["AeroArr"].ToString();
                        int numeroVoli = Convert.ToInt32(reader["NumeroVoli"]);
                        destinazioni.Add((destinazione, numeroVoli));
                    }

                    conness.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante il recupero delle destinazioni: {ex.Message}");
            }

            return destinazioni;
        }
        public int numeroVoliInTerminalPerStato(string terminal)
        {
            int numeroVoli = 0;

            try
            {
                using (SqlConnection conness = new SqlConnection(Config.credenziali))
                {
                    string query = @"
                        SELECT COUNT(*) AS NumeroVoli
                        FROM Volo
                        WHERE Terminal = @Terminal
                          AND Stato IN ('imbarco in corso', 'in partenza');";

                    SqlCommand command = new SqlCommand(query, conness);
                    command.Parameters.AddWithValue("@Terminal", terminal);

                    conness.Open();

                    
                    numeroVoli = (int)command.ExecuteScalar();

                    conness.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Errore durante il recupero dei voli: {ex.Message}");
            }

            return numeroVoli;
        }
    }
}
