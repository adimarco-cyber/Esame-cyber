﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Esame_c_.Models
{
    internal class Volo
    {
        public int Id { get; set; }
        public string? AeroPart { get; set; }
        public string? AeroArr { get; set; }
        public DateTime? Tempo { get; set; }
        public string? Codice { get; set; }
        public string? Terminal { get; set; }
        public string? Gate { get; set; }
        public string? Stato { get; set; }

        public override string ToString()
        {
            return $"Aeroporto di partenza:{AeroPart} \n Aeroporto di arrivo: {AeroArr} \n Data: {Tempo} \n Codice: {Codice} \n Terminal: {Terminal} \n Gate: {Gate} \n Stato: {Stato}";
        }


    }
}
